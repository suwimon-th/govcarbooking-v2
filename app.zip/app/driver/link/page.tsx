// app/driver/link/page.tsx
"use client";

import { useEffect, useState } from "react";
import liff from "@line/liff";

type LinkStatus = "idle" | "loading" | "success" | "error";

const LIFF_ID = process.env.NEXT_PUBLIC_LINE_LIFF_ID_DRIVER!;

export default function DriverLinkPage() {
  const [status, setStatus] = useState<LinkStatus>("loading");
  const [message, setMessage] = useState("กำลังเริ่มต้นระบบเชื่อมต่อ...");
  const [driverName, setDriverName] = useState<string | null>(null);

  useEffect(() => {
    const run = async () => {
      try {
        // 1) ตรวจว่า config ครบไหม
        if (!LIFF_ID) {
          setStatus("error");
          setMessage("ไม่พบค่า LIFF ID ในระบบ (NEXT_PUBLIC_LINE_LIFF_ID_DRIVER)");
          return;
        }

        // 2) อ่าน driver_id จาก query string
        const params = new URLSearchParams(window.location.search);
        const driverId = params.get("driver_id");

        if (!driverId) {
          setStatus("error");
          setMessage("ลิงก์ไม่ถูกต้อง: ไม่พบรหัสพนักงานขับรถ (driver_id)");
          return;
        }

        // 3) เริ่มต้น LIFF
        setMessage("กำลังเชื่อมต่อกับ LINE...");
        await liff.init({ liffId: LIFF_ID });

        if (!liff.isLoggedIn()) {
          // กลับมาหน้าเดิมพร้อม query เดิมหลัง login
          liff.login({ redirectUri: window.location.href });
          return;
        }

        // 4) ดึง userId จาก context
        const context = liff.getContext();
        const lineUserId = context?.userId;

        if (!lineUserId) {
          setStatus("error");
          setMessage("ไม่สามารถอ่าน LINE userId ได้ กรุณาเปิดลิงก์จากห้องแชท LINE OA");
          return;
        }

        // 5) เรียก API ผูก driver กับ line_user_id
        setMessage("กำลังบันทึกข้อมูลการเชื่อมต่อ...");

        const res = await fetch("/api/driver/link", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ driver_id: driverId, line_user_id: lineUserId }),
        });

        const json = await res.json().catch(() => ({}));

        if (!res.ok) {
          setStatus("error");
          setMessage(
            json?.error || "ไม่สามารถเชื่อม LINE กับระบบได้ กรุณาลองใหม่อีกครั้ง"
          );
          return;
        }

        setDriverName(json.full_name ?? null);
        setStatus("success");
        setMessage("เชื่อมบัญชี LINE กับระบบเรียบร้อยแล้ว ขอบคุณครับ");
      } catch (err) {
        console.error(err);
        setStatus("error");
        setMessage("เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่ภายหลัง");
      }
    };

    run();
  }, []);

  const isLoading = status === "loading";

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-lg max-w-md w-full p-8 text-center">
        <h1 className="text-2xl font-bold text-blue-800 mb-4">
          เชื่อมบัญชี LINE สำหรับพนักงานขับรถ
        </h1>

        {driverName && (
          <p className="mb-2 text-gray-700">
            พนักงานขับรถ: <span className="font-semibold">{driverName}</span>
          </p>
        )}

        {/* ไอคอนสถานะ */}
        <div className="mb-4 flex justify-center">
          {isLoading && (
            <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
          )}

          {status === "success" && (
            <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white text-2xl">
              ✓
            </div>
          )}

          {status === "error" && (
            <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center text-white text-2xl">
              !
            </div>
          )}
        </div>

        <p className="text-gray-700 mb-4 leading-relaxed">{message}</p>

        {status === "success" && (
          <p className="text-sm text-gray-500">
            เมื่อเชื่อมสำเร็จแล้ว คุณสามารถปิดหน้านี้ได้เลย
          </p>
        )}

        {status === "error" && (
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700"
          >
            ลองใหม่อีกครั้ง
          </button>
        )}
      </div>
    </div>
  );
}
