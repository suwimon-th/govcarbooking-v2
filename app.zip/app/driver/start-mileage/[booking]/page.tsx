"use client";

import { useState, useEffect } from "react";

interface BookingInfo {
  id: string;
  request_code: string;
  requester_name: string;
  vehicle_id: string;
  start_mileage?: number;
}

export default function StartMileagePage({
  params,
}: {
  params: { booking: string };
}) {
  const bookingId = params.booking; // <-- ดึงจาก Dynamic Route

  const [booking, setBooking] = useState<BookingInfo | null>(null);
  const [error, setError] = useState("");
  const [mileage, setMileage] = useState("");
  const [loading, setLoading] = useState(false);

  // โหลด booking จาก API
  useEffect(() => {
    async function load() {
      if (!bookingId) {
        setError("ไม่พบหมายเลขงาน (booking)");
        return;
      }

      const res = await fetch(`/api/mileage/get-booking?booking=${bookingId}`, {
        cache: "no-store",
      });

      const json = await res.json();

      if (json.error) setError(json.error);
      else setBooking(json.booking);
    }

    load();
  }, [bookingId]);

  // บันทึกเลขไมล์เริ่มต้น
  const submit = async () => {
    if (!booking) return;

    setLoading(true);

    const res = await fetch("/api/mileage/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bookingId: booking.id,
        mileage,
      }),
    });

    const json = await res.json();
    setLoading(false);

    alert(json.message || json.error);
  };

  if (error) return <p className="p-6 text-red-600">{error}</p>;
  if (!booking) return <p className="p-6">กำลังโหลดข้อมูลงาน...</p>;

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-2">กรอกเลขไมล์เริ่มต้น</h1>

      <div className="border p-3 mb-4 rounded bg-gray-50">
        <p>รหัสคำขอ: {booking.request_code}</p>
        <p>ผู้ขอใช้: {booking.requester_name}</p>
        <p>รถที่ใช้: {booking.vehicle_id}</p>
      </div>

      <input
        type="number"
        value={mileage}
        onChange={(e) => setMileage(e.target.value)}
        className="border p-2 w-full"
        placeholder="เลขไมล์เริ่มต้น"
      />

      <button
        onClick={submit}
        disabled={loading}
        className="mt-4 bg-blue-600 text-white p-3 rounded w-full disabled:opacity-50"
      >
        {loading ? "กำลังบันทึก..." : "บันทึกเลขไมล์เริ่มต้น"}
      </button>
    </div>
  );
}
