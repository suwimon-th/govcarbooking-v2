/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Calendar, Clock, Car, Users } from "lucide-react";

/* ---------------------------
   Types
--------------------------- */
interface RecentBooking {
  id: string;
  requester_name: string;
  purpose: string;
  status: string;
  start_at: string;
}

/* ---------------------------
   Main Component
--------------------------- */
export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalBookings: 0,
    pendingRequests: 0,
    totalVehicles: 0,
    totalDrivers: 0,
  });

  const [recent, setRecent] = useState<RecentBooking[]>([]);

  /* ---------------------------
     Load Data
  --------------------------- */
  async function loadStats() {
    // total bookings
    const { count: totalBookings } = await supabase
      .from("bookings")
      .select("*", { count: "exact", head: true });

    // pending
    const { count: pendingRequests } = await supabase
      .from("bookings")
      .select("*", { count: "exact", head: true })
      .eq("status", "REQUESTED");

    // vehicles
    const { count: totalVehicles } = await supabase
      .from("vehicles")
      .select("*", { count: "exact", head: true });

    // drivers
    const { count: totalDrivers } = await supabase
      .from("drivers")
      .select("*", { count: "exact", head: true });

    // recent bookings
    const { data: recentBookings } = await supabase
      .from("bookings")
      .select("id, requester_name, purpose, status, start_at")
      .order("created_at", { ascending: false })
      .limit(5);

    setStats({
      totalBookings: totalBookings ?? 0,
      pendingRequests: pendingRequests ?? 0,
      totalVehicles: totalVehicles ?? 0,
      totalDrivers: totalDrivers ?? 0,
    });

    setRecent((recentBookings ?? []) as RecentBooking[]);
  }

  useEffect(() => {
    loadStats();
  }, []);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-1">Admin Dashboard</h1>
      <p className="text-gray-500 mb-6">
        Overview of your fleet management system
      </p>

      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card title="Total Bookings" icon={<Calendar />} value={stats.totalBookings} />
        <Card title="Pending Requests" icon={<Clock />} value={stats.pendingRequests} />
        <Card title="Total Vehicles" icon={<Car />} value={stats.totalVehicles} />
        <Card title="Total Drivers" icon={<Users />} value={stats.totalDrivers} />
      </div>

      {/* Recent */}
      <h2 className="text-xl font-bold mb-3">Recent Booking Requests</h2>

      <div className="space-y-3">
        {recent.map((item) => (
          <div
            key={item.id}
            className="border rounded-xl p-4 bg-white shadow-sm flex justify-between"
          >
            <div>
              <p className="font-semibold">{item.purpose}</p>
              <p className="text-sm text-gray-500">{item.requester_name}</p>
            </div>

            <div className="text-right">
              <p
                className={`font-semibold ${
                  item.status === "REQUESTED" ? "text-orange-500" : "text-green-600"
                }`}
              >
                {item.status}
              </p>

              <p className="text-sm text-gray-500">
                {new Date(item.start_at).toLocaleDateString("th-TH")}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------
   Card Component
--------------------------- */
function Card({
  title,
  icon,
  value,
}: {
  title: string;
  icon: React.ReactNode;
  value: number;
}) {
  return (
    <div className="bg-white shadow-sm rounded-xl p-6 border">
      <div className="flex items-center justify-between">
        <p className="text-gray-600 font-medium">{title}</p>
        <div className="text-gray-600 w-5 h-5">{icon}</div>
      </div>
      <p className="text-3xl font-bold mt-3">{value}</p>
    </div>
  );
}
