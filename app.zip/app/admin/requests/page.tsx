/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import EditBookingModal from "./EditBookingModal";

// =========================
// TYPES
// =========================

interface RequesterInfo {
  full_name: string | null;
}

interface DriverInfo {
  full_name: string | null;
}

interface VehicleInfo {
  plate_number: string | null;
  brand: string | null;
  model: string | null;
}

interface MileageInfo {
  start_mileage: number | null;
  end_mileage: number | null;
}

export interface BookingRow {
  id: string;
  request_code: string;
  requester_id: string;
  driver_id: string | null;
  vehicle_id: string | null;
  purpose: string | null;
  start_at: string | null;
  end_at: string | null;
  status: string;

  requester: RequesterInfo | null;
  driver: DriverInfo | null;
  vehicle: VehicleInfo | null;
  mileage: MileageInfo[] | null;
}

// =========================
// FORMAT DATE THAI
// =========================

const formatThaiDateTime = (value: string | null): string => {
  if (!value) return "-";

  const date = new Date(value);

  const thaiMonths = [
    "มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน",
    "กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม"
  ];

  const day = date.getDate();
  const month = thaiMonths[date.getMonth()];
  const year = date.getFullYear() + 543;

  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");

  return `${day} ${month} ${year} เวลา ${hours}:${minutes} น.`;
};

// =========================
// MAIN PAGE
// =========================

export default function AdminRequestsPage() {
  const [rows, setRows] = useState<BookingRow[]>([]);
  const [editItem, setEditItem] = useState<BookingRow | null>(null);

  const loadData = async (): Promise<void> => {
    const { data, error } = await supabase
      .from("bookings")
      .select(
        `
        id,
        request_code,
        requester_id,
        driver_id,
        vehicle_id,
        purpose,
        start_at,
        end_at,
        status,

        requester:requester_id(full_name),

        driver:driver_id(full_name),

        vehicle:vehicle_id(
          plate_number,
          brand,
          model
        ),

        mileage:booking_mileage(start_mileage, end_mileage)
      `
      )
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error loading bookings:", error);
      return;
    }

    if (data) {
      setRows(data as unknown as BookingRow[]);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const deleteBooking = async (id: string): Promise<void> => {
    if (!confirm("ต้องการลบคำขอนี้หรือไม่?")) return;

    const { error } = await supabase.from("bookings").delete().eq("id", id);
    if (error) {
      console.error("Error deleting booking:", error);
      return;
    }

    await loadData();
  };

  const statusColor = (status: string): string => {
    switch (status) {
      case "REQUESTED": return "bg-gray-500";
      case "APPROVED": return "bg-green-600";
      case "REJECTED": return "bg-red-600";
      case "ASSIGNED": return "bg-blue-600";
      case "ACCEPTED": return "bg-indigo-600";
      case "IN_PROGRESS": return "bg-yellow-600";
      case "COMPLETED": return "bg-purple-600";
      case "CANCELLED": return "bg-zinc-500";
      default: return "bg-gray-600";
    }
  };

  const vehicleDisplay = (v: VehicleInfo | null): string => {
    if (!v) return "-";
    if (!v.plate_number) return "-";

    return `${v.plate_number} (${v.brand ?? ""} ${v.model ?? ""})`;
  };

  return (
    <div className="p-4 md:p-8 max-w-[1400px] mx-auto">
      <h1 className="text-2xl font-bold mb-6">จัดการคำขอใช้รถทั้งหมด</h1>

      {/* DESKTOP TABLE */}
      <div className="hidden md:block">
        <table className="w-full border border-gray-300 rounded-lg text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2">รหัสคำขอ</th>
              <th className="border p-2">ผู้ขอ</th>
              <th className="border p-2">วัตถุประสงค์</th>
              <th className="border p-2">เริ่มต้น</th>
              <th className="border p-2">สิ้นสุด</th>
              <th className="border p-2">คนขับรถ</th>
              <th className="border p-2">ทะเบียนรถ</th>
              <th className="border p-2">เลขไมล์ก่อนออก</th>
              <th className="border p-2">เลขไมล์หลังออก</th>
              <th className="border p-2">สถานะ</th>
              <th className="border p-2">จัดการ</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((b) => (
              <tr key={b.id} className="hover:bg-gray-50">
                <td className="border p-2">{b.request_code}</td>
                <td className="border p-2">{b.requester?.full_name || "-"}</td>
                <td className="border p-2">{b.purpose || "-"}</td>
                <td className="border p-2">{formatThaiDateTime(b.start_at)}</td>
                <td className="border p-2">{formatThaiDateTime(b.end_at)}</td>
                <td className="border p-2">{b.driver?.full_name || "-"}</td>

                {/* แสดงทะเบียนรถ + รุ่น */}
                <td className="border p-2">{vehicleDisplay(b.vehicle)}</td>

                <td className="border p-2">
                  {b.mileage?.[0]?.start_mileage ?? "-"}
                </td>
                <td className="border p-2">
                  {b.mileage?.[0]?.end_mileage ?? "-"}
                </td>

                <td className="border p-2">
                  <span
                    className={`inline-flex px-3 py-1 text-xs font-semibold text-white rounded-full ${statusColor(
                      b.status
                    )}`}
                  >
                    {b.status}
                  </span>
                </td>

                <td className="border p-2">
                  <div className="flex items-center justify-center gap-2">
                    <button
                      onClick={() => setEditItem(b)}
                      className="w-8 h-8 flex items-center justify-center rounded-md bg-yellow-500 hover:bg-yellow-600 text-white text-sm shadow-sm"
                      title="แก้ไข"
                    >
                      ✏️
                    </button>
                    <button
                      onClick={() => deleteBooking(b.id)}
                      className="w-8 h-8 flex items-center justify-center rounded-md bg-red-600 hover:bg-red-700 text-white text-sm shadow-sm"
                      title="ลบ"
                    >
                      🗑️
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* MOBILE LIST */}
      <div className="md:hidden space-y-4">
        {rows.map((b) => (
          <div
            key={b.id}
            className="border p-4 rounded-xl shadow-sm bg-white space-y-2"
          >
            <div className="flex justify-between items-center">
              <p className="text-lg font-semibold">{b.request_code}</p>

              <span
                className={`px-2 py-1 text-xs text-white rounded-full ${statusColor(
                  b.status
                )}`}
              >
                {b.status}
              </span>
            </div>

            <p><strong>ผู้ขอ:</strong> {b.requester?.full_name || "-"}</p>
            <p><strong>วัตถุประสงค์:</strong> {b.purpose || "-"}</p>
            <p><strong>เริ่มต้น:</strong> {formatThaiDateTime(b.start_at)}</p>
            <p><strong>สิ้นสุด:</strong> {formatThaiDateTime(b.end_at)}</p>
            <p><strong>คนขับ:</strong> {b.driver?.full_name || "-"}</p>

            <p><strong>ทะเบียนรถ:</strong> {vehicleDisplay(b.vehicle)}</p>

            <p>
              <strong>เลขไมล์ก่อนออก:</strong>{" "}
              {b.mileage?.[0]?.start_mileage ?? "-"}
            </p>
            <p>
              <strong>เลขไมล์หลังออก:</strong>{" "}
              {b.mileage?.[0]?.end_mileage ?? "-"}
            </p>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setEditItem(b)}
                className="flex-1 py-2 rounded-md bg-yellow-500 text-white text-sm"
              >
                ✏️ แก้ไข
              </button>
              <button
                onClick={() => deleteBooking(b.id)}
                className="flex-1 py-2 rounded-md bg-red-600 text-white text-sm"
              >
                🗑️ ลบ
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {editItem && (
        <EditBookingModal
          booking={editItem}
          onClose={() => setEditItem(null)}
          onUpdated={loadData}
        />
      )}
    </div>
  );
}
