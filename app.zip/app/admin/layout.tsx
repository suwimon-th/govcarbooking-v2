"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [loggingOut, setLoggingOut] = useState(false);

  // ===== ชื่อหน้าไว้ใช้กับ breadcrumb =====
  const breadcrumbTitles: Record<string, string> = {
    "/admin": "หน้าแรก",
    "/admin/requests": "คำขอใช้รถ",
    "/admin/vehicles": "รถทั้งหมด",
    "/admin/drivers": "คนขับรถ",
    "/admin/users": "ผู้ใช้งาน",
  };

  const currentTitle = breadcrumbTitles[pathname] ?? "";

  // ===== ออกจากระบบ =====
  const handleLogout = async (): Promise<void> => {
    try {
      setLoggingOut(true);
      // ถ้าไม่ได้ใช้ Supabase Auth จริง ๆ การเรียกนี้ก็ไม่เป็นไร
      await supabase.auth.signOut().catch(() => {});
      router.push("/login"); // เปลี่ยนเส้นทางไปหน้า login admin
    } finally {
      setLoggingOut(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* TOP HEADER */}
      <header className="w-full bg-white shadow-sm border-b fixed top-0 left-0 z-40">
        <div className="max-w-[1400px] mx-auto px-4 md:px-6 py-3 flex items-center justify-between gap-4">
          {/* ปุ่มกลับหน้าแรก */}
          <button
            onClick={() => router.push("/admin")}
            className="px-3 py-1 rounded-md bg-gray-200 hover:bg-gray-300 text-xs md:text-sm whitespace-nowrap"
          >
            ⬅️ กลับหน้าแรก
          </button>

          {/* ชื่อระบบ */}
          <h1 className="text-sm md:text-lg font-bold text-center flex-1">
            ระบบบริหารการใช้รถราชการ
          </h1>

          {/* เมนู + ออกจากระบบ */}
          <div className="flex items-center gap-3 text-xs md:text-sm">
            <nav className="hidden md:flex items-center gap-3">
              <Link href="/admin/requests" className="hover:underline">
                คำขอใช้รถ
              </Link>
              <Link href="/admin/vehicles" className="hover:underline">
                รถทั้งหมด
              </Link>
              <Link href="/admin/drivers" className="hover:underline">
                คนขับรถ
              </Link>
              <Link href="/admin/users" className="hover:underline">
                ผู้ใช้งาน
              </Link>
            </nav>

            <button
              onClick={handleLogout}
              disabled={loggingOut}
              className="px-3 py-1 rounded-md bg-red-600 hover:bg-red-700 text-white"
            >
              {loggingOut ? "กำลังออก..." : "ออกจากระบบ"}
            </button>
          </div>
        </div>
      </header>

      {/* BREADCRUMB */}
      <div className="pt-20 px-4 md:px-6">
        <div className="text-xs md:text-sm text-gray-600 mb-3">
          <Link href="/admin" className="text-blue-600 hover:underline">
            หน้าแรก
          </Link>
          {pathname !== "/admin" && currentTitle && (
            <>
              {" "}
              / <span className="text-gray-800">{currentTitle}</span>
            </>
          )}
        </div>
      </div>

      {/* เนื้อหาหน้า */}
      <main className="px-4 md:px-8 pb-8">{children}</main>
    </div>
  );
}
