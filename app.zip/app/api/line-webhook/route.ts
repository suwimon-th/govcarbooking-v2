/* eslint-disable @typescript-eslint/no-unused-vars */
import { NextResponse } from "next/server";
import crypto from "crypto";
import { sendLinePush, flexDriverAcceptSuccess } from "@/app/lib/line";

// เราเก็บฟังก์ชันไว้ เผื่อเปิดใช้ภายหลัง แต่ยังไม่เรียกใช้งาน
function validateSignature(body: string, signature: string | null, channelSecret: string) {
  if (!signature) return false;

  const computed = crypto
    .createHmac("SHA256", channelSecret)
    .update(body)
    .digest("base64");

  return computed === signature;
}

export async function POST(req: Request) {
  try {
    const secret = process.env.LINE_CHANNEL_SECRET;
    if (!secret) {
      console.error("❌ LINE_CHANNEL_SECRET missing");
      return NextResponse.json({ error: "server config error" }, { status: 500 });
    }

    const rawBody = await req.text();
    const signature = req.headers.get("x-line-signature");

    // 🔍 DEBUG: log rawBody + signature ดูก่อน
    console.log("🔍 /api/line-webhook called");
    console.log("🔍 x-line-signature =", signature);
    console.log("🔍 rawBody =", rawBody);

    // ⛔ ปิดการตรวจ signature ชั่วคราว (เพราะตอนนี้มัน 400 ตลอด)
    // ถ้าต้องการเปิดใช้อีกครั้ง เปลี่ยนเป็น if (...)
    /*
    if (!validateSignature(rawBody, signature, secret)) {
      console.error("❌ Invalid signature");
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
    }
    */

    const body = JSON.parse(rawBody);

    if (!body.events || !Array.isArray(body.events)) {
      console.error("❌ No events in webhook body");
      return NextResponse.json({ error: "No events" }, { status: 200 });
    }

    // ===============================
    // LOOP EVENT
    // ===============================
    for (const event of body.events) {
      console.log("🔔 EVENT TYPE:", event.type);

      // ======================
      // 1) POSTBACK: รับงาน
      // ======================
      if (event.type === "postback") {
        try {
          console.log("📩 POSTBACK RAW DATA:", event.postback.data);

          const data = JSON.parse(event.postback.data);

          if (data.type === "ACCEPT_JOB") {
            const bookingId = data.booking_id;
            const userId = event.source.userId;

            console.log("✅ DRIVER ACCEPT JOB:", { bookingId, userId });

            await updateBookingStatus(bookingId, "ACCEPTED");

            await sendLinePush(userId, flexDriverAcceptSuccess(bookingId));

            continue;
          }
        } catch (err) {
          console.error("❌ Postback Error:", err);
        }
      }

      // message event
      if (event.type === "message") {
        console.log("💬 MESSAGE EVENT:", event.message);
        continue;
      }

      if (event.type === "follow") {
        console.log("🙋 FOLLOW EVENT");
        continue;
      }
      if (event.type === "unfollow") {
        console.log("👋 UNFOLLOW EVENT");
        continue;
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("🔥 Webhook Error:", err);
    return NextResponse.json({ error: "Webhook internal error" }, { status: 500 });
  }
}

// ============== อัปเดตสถานะ Booking ==============
async function updateBookingStatus(bookingId: string, status: string) {
  console.log("🔄 updateBookingStatus:", bookingId, status);

  await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/admin/update-booking-status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ bookingId, status }),
  });
}
