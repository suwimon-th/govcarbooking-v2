// app/api/driver/link/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: Request) {
  try {
    const { driver_id, line_user_id } = await req.json();

    if (!driver_id || !line_user_id) {
      return NextResponse.json(
        { error: "ข้อมูลไม่ครบ (driver_id / line_user_id)" },
        { status: 400 }
      );
    }

    // อัปเดต driver ให้เก็บ line_user_id
    const { data, error } = await supabaseAdmin
      .from("drivers")
      .update({ line_user_id: line_user_id })
      .eq("id", driver_id)
      .select("id, full_name")
      .single();

    if (error || !data) {
      return NextResponse.json(
        { error: "ไม่พบข้อมูลพนักงานขับรถ หรืออัปเดตไม่สำเร็จ" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      full_name: data.full_name,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { error: "Server error" },
      { status: 500 }
    );
  }
}
