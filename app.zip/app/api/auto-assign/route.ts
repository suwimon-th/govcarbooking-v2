/* eslint-disable @typescript-eslint/no-unused-vars */
import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseClient";
import crypto from "crypto";

type DriverRow = {
  id: string;
  full_name: string | null;
  line_user_id: string | null;
  queue_order: number | null;
  active: boolean | null;
};

type BookingRow = {
  id: string;
  request_code: string | null;
  requester_id: string;
  requester_name: string | null;
  department_id: number;
  start_at: string;
  end_at: string | null;
  purpose: string | null;
};

function createSecureToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

const WORKER_URL = process.env.LINE_PUSH_ENDPOINT;

// =====================================================
// POST: /api/auto-assign
// =====================================================
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const bookingId = body.bookingId as string;

    if (!bookingId) {
      return NextResponse.json(
        { error: "Missing bookingId" },
        { status: 400 }
      );
    }

    console.log("🔄 Auto-assigning booking:", bookingId);

    // 1) โหลดรายละเอียด booking
    const { data: bookingRaw, error: bookingErr } = await supabase
      .from("bookings")
      .select(
        `
        id,
        request_code,
        requester_id,
        requester_name,
        department_id,
        start_at,
        end_at,
        purpose
      `
      )
      .eq("id", bookingId)
      .single();

    if (bookingErr || !bookingRaw) {
      console.error("❌ Booking not found:", bookingErr);
      return NextResponse.json(
        { error: "Booking not found" },
        { status: 404 }
      );
    }

    const booking = bookingRaw as BookingRow;
    console.log("📋 Booking loaded:", booking.request_code);

    // 2) โหลดคิวคนขับ (active + เรียงตาม queue_order)
    const { data: driversRaw, error: driverErr } = await supabase
      .from("drivers")
      .select(
        `
        id,
        full_name,
        line_user_id,
        queue_order,
        active
      `
      )
      .eq("active", true)
      .eq("status", "AVAILABLE")
      .order("queue_order", { ascending: true });

    if (driverErr || !driversRaw || driversRaw.length === 0) {
      console.error("❌ No available drivers:", driverErr);
      return NextResponse.json(
        { error: "No drivers available" },
        { status: 500 }
      );
    }

    const drivers = driversRaw as DriverRow[];
    const driver = drivers[0]; // เลือกคนขับคนแรกในคิว

    console.log("👤 Driver assigned:", driver.full_name);

    // 3) อัปเดต booking ให้ assign คนแรกในคิว
    const nowIso = new Date().toISOString();

    const { error: updateErr } = await supabase
      .from("bookings")
      .update({
        driver_id: driver.id,
        assigned_at: nowIso,
        status: "ASSIGNED",
      })
      .eq("id", bookingId);

    if (updateErr) {
      console.error("❌ Failed to update booking:", updateErr);
      return NextResponse.json(
        { error: "Failed to update booking" },
        { status: 500 }
      );
    }

    // 4) อัปเดตสถานะคนขับเป็น BUSY
    await supabase
      .from("drivers")
      .update({ status: "BUSY" })
      .eq("id", driver.id);

    // 5) สร้าง token สำหรับให้คนขับกดรับงาน
    const token = createSecureToken();
    const expireAt = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // หมดอายุใน 1 ชั่วโมง

    await supabase.from("booking_tokens").insert({
      token,
      booking_id: bookingId,
      action: "ACCEPT",
      expire_at: expireAt,
      used: false,
    });

    console.log("🔑 Token created for driver acceptance");

    // 6) ส่งข้อความ LINE ผ่าน Cloudflare Worker
    if (WORKER_URL && driver.line_user_id) {
      console.log("📱 Sending LINE notification to:", driver.line_user_id);

      const message = createFlexAssignMessage(
        booking,
        driver.full_name ?? "คนขับ",
        token
      );

      try {
        const lineResponse = await fetch(WORKER_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            to: driver.line_user_id,
            messages: [message],
          }),
        });

        if (lineResponse.ok) {
          console.log("✅ LINE notification sent successfully");
        } else {
          console.error("⚠️ LINE notification failed:", await lineResponse.text());
        }
      } catch (lineErr) {
        console.error("⚠️ LINE notification error:", lineErr);
      }
    } else {
      console.log("⚠️ LINE notification skipped (no URL or line_user_id)");
    }

    return NextResponse.json({
      success: true,
      driverAssigned: driver.full_name ?? "ไม่ระบุชื่อ",
      bookingCode: booking.request_code,
    });

  } catch (err) {
    console.error("🔥 AUTO_ASSIGN_ERROR:", err);
    return NextResponse.json(
      { error: "UNEXPECTED_ERROR" },
      { status: 500 }
    );
  }
}

// =====================================================
// สร้าง Flex Message สำหรับ LINE
// =====================================================
function createFlexAssignMessage(
  booking: BookingRow,
  driverName: string,
  token: string   // ❗ ไม่จำเป็นอีกต่อไป แต่คงไว้เพราะระบบเก่าใช้
) {
  const startDate = new Date(booking.start_at);
  const formattedDate = startDate.toLocaleString("th-TH", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return {
    type: "flex",
    altText: `🚗 งานใหม่: ${booking.request_code}`,
    contents: {
      type: "bubble",
      size: "mega",

      header: {
        type: "box",
        layout: "vertical",
        contents: [
          {
            type: "text",
            text: "🚗 มีงานใหม่เข้ามา",
            weight: "bold",
            size: "xl",
            color: "#FFFFFF",
          },
        ],
        backgroundColor: "#1E88E5",
        paddingAll: "20px",
      },

      body: {
        type: "box",
        layout: "vertical",
        contents: [
          {
            type: "text",
            text: `รหัสงาน: ${booking.request_code}`,
            weight: "bold",
            size: "lg",
            margin: "md",
          },
          {
            type: "separator",
            margin: "lg",
          },
          {
            type: "box",
            layout: "vertical",
            margin: "lg",
            spacing: "sm",
            contents: [
              {
                type: "box",
                layout: "baseline",
                spacing: "sm",
                contents: [
                  { type: "text", text: "👤 ผู้ขอ:", size: "sm", color: "#AAAAAA", flex: 2 },
                  { type: "text", text: booking.requester_name ?? "-", size: "sm", wrap: true, flex: 5 }
                ],
              },
              {
                type: "box",
                layout: "baseline",
                spacing: "sm",
                contents: [
                  { type: "text", text: "📅 เวลา:", size: "sm", color: "#AAAAAA", flex: 2 },
                  { type: "text", text: formattedDate, size: "sm", wrap: true, flex: 5 }
                ],
              },
              {
                type: "box",
                layout: "baseline",
                spacing: "sm",
                contents: [
                  { type: "text", text: "📝 วัตถุประสงค์:", size: "sm", color: "#AAAAAA", flex: 2 },
                  { type: "text", text: booking.purpose ?? "-", size: "sm", wrap: true, flex: 5 }
                ],
              },
            ],
          },
        ],
        paddingAll: "20px",
      },

      footer: {
        type: "box",
        layout: "vertical",
        spacing: "sm",
        contents: [
          {
            type: "button",
            style: "primary",
            height: "sm",
            color: "#4CAF50",
            action: {
              type: "postback",
              label: "✔ รับงาน",
              data: JSON.stringify({
                type: "ACCEPT_JOB",
                booking_id: booking.id,
              }),
            },
          },
          {
            type: "text",
            text: "กรุณากดปุ่มรับงานภายใน 1 ชั่วโมง",
            color: "#999999",
            size: "xxs",
            align: "center",
            margin: "md",
          },
        ],
        paddingAll: "20px",
      },
    },
  };
}
