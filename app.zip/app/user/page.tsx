"use client";

import Header from "../components/Header";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { EventInput } from "@fullcalendar/core";
import { useEffect, useState } from "react";

type Booking = {
  purpose: string | null;
  start_at: string;
  end_at: string | null;
};

export default function UserDashboard() {
  const [events, setEvents] = useState<EventInput[]>([]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/get-bookings");
        const data = await res.json();

        const formatted: EventInput[] = data.map((item: Booking) => ({
          title: item.purpose || "ใช้งานรถ",
          start: item.start_at,
          end: item.end_at,
          color: "#0D47A1",
        }));

        setEvents(formatted);
      } catch (error) {
        console.error("Load calendar error:", error);
      }
    }

    load();
  }, []);

  return (
    <>
      <Header />

      <div className="p-6">
        <div className="card">
          <h2 className="text-xl font-semibold text-[var(--primary)] mb-4">
            ปฏิทินการใช้รถราชการ
          </h2>

          <FullCalendar
            plugins={[dayGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            locale="th"
            height="auto"
            events={events}
            dateClick={(info) => {
              window.location.href = "/user/request?date=" + info.dateStr;
            }}
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: "",
            }}
            dayMaxEvents={true}
            eventDisplay="block"
          />
        </div>
      </div>
    </>
  );
}
