/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
// app/lib/line.ts

// ======================================================
// ส่งข้อความ PUSH ไปยัง LINE
// ======================================================
export async function sendLinePush(to: string, messages: any[]) {
  const token = process.env.LINE_CHANNEL_ACCESS_TOKEN;

  if (!token) {
    console.error("❌ LINE_CHANNEL_ACCESS_TOKEN missing");
    return false;
  }

  const res = await fetch("https://api.line.me/v2/bot/message/push", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      to,
      messages,
    }),
  });

  if (!res.ok) {
    console.error("❌ LINE push error", await res.text());
    return false;
  }

  return true;
}

// ======================================================
// Flex แจ้งงานให้คนขับ (ปุ่มรับงานแบบ POSTBACK)
// ======================================================
export function flexAssignDriver(booking: any, vehicle: any, driver: any) {
  const messages = [
    {
      type: "flex",
      altText: "มีงานใหม่สำหรับคุณ",
      contents: {
        type: "bubble",
        size: "mega",
        body: {
          type: "box",
          layout: "vertical",
          spacing: "md",
          contents: [
            {
              type: "text",
              text: "🚘 งานใหม่เข้ามา",
              weight: "bold",
              size: "lg",
            },
            {
              type: "text",
              text: `รถ: ${vehicle.plate_no}`,
              wrap: true,
            },
            {
              type: "text",
              text: `งาน: ${booking.purpose}`,
              wrap: true,
            },
            {
              type: "button",
              style: "primary",
              color: "#1B75D0",
              margin: "lg",
              action: {
                type: "postback",
                label: "✔ รับงาน",
                data: JSON.stringify({
                  type: "ACCEPT_JOB",
                  booking_id: booking.id,
                }),
              },
            },
          ],
        },
      },
    },
  ];

  return messages;
}

// ======================================================
// Flex แจ้งว่า "รับงานสำเร็จ"
// ======================================================
export function flexDriverAcceptSuccess(bookingId: string) {
  return [
    {
      type: "flex",
      altText: "รับงานสำเร็จ",
      contents: {
        type: "bubble",
        body: {
          type: "box",
          layout: "vertical",
          spacing: "md",
          contents: [
            {
              type: "text",
              text: "📌 รับงานสำเร็จ!",
              weight: "bold",
              size: "lg",
              color: "#16a34a",
            },
            {
              type: "text",
              text: "กรุณากรอกเลขไมล์เริ่มต้นก่อนออกเดินทาง",
              wrap: true,
            },
            {
              type: "button",
              style: "primary",
              color: "#0284c7",
              action: {
                type: "uri",
                label: "กรอกเลขไมล์เริ่มต้น",
                uri: `${process.env.NEXT_PUBLIC_BASE_URL}/driver/start-mileage/${bookingId}`,
              },
            },
          ],
        },
      },
    },
  ];
}

// ======================================================
// ส่ง Flex Assign
// ======================================================
export async function pushAssignDriver(to: string, booking: any, vehicle: any, driver: any) {
  const messages = flexAssignDriver(booking, vehicle, driver);
  return await sendLinePush(to, messages);
}
